﻿module Program

open System
open System.IO

// ...

[<EntryPoint>]
let main argv =
    // ...
    0
        