import sys
#import functools
#import operator

# ...

def main ():
    # ...
    pass
        
main ()

