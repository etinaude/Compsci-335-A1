using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

class Program {
// ...

static void Main () {
    // ...
}
}

